<?php
if(isset($_POST['addsalary'])){
    $emp_ids = $_POST['emp_id'];
    $amounts = $_POST['amount'];
    $created_by = (int) $_SESSION['userid'];
    $conn->begin_transaction();
    try {
        for($i = 0; $i < count($emp_ids); $i++){
            $emp_id = (int) $emp_ids[$i];
            $amount = floatval(str_replace(',', '', $amounts[$i]));
            $sql = "INSERT INTO `salary` (`subsidiary_id`, `amount`) VALUES ($emp_id, $amount)";
            if(!$conn->query($sql)){
                throw new Exception($conn->error);
            }
        }
        $conn->commit();
        setNotification('success', 'Basic salary added successfully');
        echo "<script>window.location.href='./?page=add_basic_salary';</script>";
    } catch(Exception $e){
        $conn->rollback();
        echo $e->getMessage();
    }
}
?>

<div class="card card-success">
    <div class="card-header">
        <h4>Add Basic Salary Portal</h4>
    </div>
    <div class="card-body">
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
            <div class="mb-3">
                <button type="button" class="btn btn-info btn-sm" onclick="addSalaryRow()">Add Row</button>
                <button type="button" class="btn btn-outline-info btn-sm" onclick="removeSalaryRow()">Remove Row</button>
            </div>
            <table class="table table-bordered" id="wages-table">
                <thead>
                    <tr>
                        <th>Emp Name</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <select name="emp_id[]" class="form-control select2-form select2bs4-form" required>
                                <option value="">Select Below</option>
                                <?php
                                $sql = "SELECT s.id, s.name 
                                        FROM subsidiaries s 
                                        LEFT JOIN salary sal ON sal.subsidiary_id = s.id AND sal.deleted_at IS NULL
                                        WHERE s.type='staff' 
                                        AND s.deleted_at IS NULL 
                                        AND sal.id IS NULL 
                                        ORDER BY s.name";
                                $result = $conn->query($sql);
                                if($result->num_rows > 0){
                                    while($rows = $result->fetch_assoc()){
                                ?>
                                <option value="<?php echo $rows['id']?>"><?php echo $rows['name']?></option>
                                <?php
                                    }
                                }
                                ?>
                            </select>
                        </td>
                        <td>
                            <input type="text" name="amount[]" class="form-control format-number" required>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="card-footer">
                <button type="submit" name="addsalary" class="btn btn-primary">Add Data</button>
            </div>
        </form>
    </div>
</div>

<script>
function addSalaryRow() {
    var table = document.getElementById("wages-table").getElementsByTagName('tbody')[0];
    var newRow = table.rows[0].cloneNode(true);
    var selects = newRow.getElementsByTagName('select');
    var inputs = newRow.getElementsByTagName('input');
    for(var i = 0; i < selects.length; i++) selects[i].selectedIndex = 0;
    for(var i = 0; i < inputs.length; i++) inputs[i].value = '';
    table.appendChild(newRow);
    if(typeof initializeSelect2 === 'function') initializeSelect2();
}
function removeSalaryRow() {
    var table = document.getElementById("wages-table").getElementsByTagName('tbody')[0];
    if(table.rows.length > 1) table.deleteRow(table.rows.length - 1);
}
</script>