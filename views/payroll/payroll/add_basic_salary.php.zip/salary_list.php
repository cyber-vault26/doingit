
                    <div class="container mb-3 mt-3">
                        <?php
                        $sql = "SELECT subsidiaries.name, salary.* FROM subsidiaries, salary 
                                WHERE subsidiaries.id = salary.subsidiary_id 
                                AND salary.deleted_at IS NULL 
                                ORDER BY subsidiaries.name";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0):
                            $counter = 1;
                            echo "<table class='table table'>";
                            echo "<thead class='thead-primary'>";
                            echo "<tr><th>#</th><th>Name</th><th>Amount (basic salary)</th><th>Action</th></tr>";
                            echo "</thead><tbody>";
                
                            while ($rows = $result->fetch_assoc()):
                                echo "<tr>";
                                echo "<td>$counter</td>";
                                echo "<td>" . htmlspecialchars($rows['name']) . "</td>";
                                echo "<td>" . number_format($rows['amount'], 2) . "</td>";
                                echo "<td>
                                    <!-- Edit Button -->
                                    <button type='button' class='btn btn-sm btn-primary' data-toggle='modal' data-target='#editModal_{$rows['id']}'>Edit</button>
                
                                    <!-- Preview Button -->
                                    <a href='./?page=preview_salary_receipt&id={$rows['id']}&staff_id={$rows['subsidiary_id']}&bs={$rows['amount']}' class='btn btn-sm btn-info'>Preview Salary Receipt</a>
                
                                    <!-- Remove Button -->
                                    <form method='POST' style='display:inline;' onsubmit='return confirm(\"Are you sure you want to remove this salary record?\");'>
                                        <input type='hidden' name='delete_id' value='{$rows['id']}'>
                                        <button type='submit' name='deletecred' class='btn btn-sm btn-danger'>Remove</button>
                                    </form>
                                </td>";
                                echo "</tr>";
                
                                // Bootstrap Modal for Edit
                                ?>
                                <div class="modal fade" id="editModal_<?= $rows['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel_<?= $rows['id'] ?>" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <form method="POST">
                                            <input type="hidden" name="edit_id" value="<?= $rows['id'] ?>">
                                            <div class="modal-content">
                                                <div class="modal-header bg-primary text-white">
                                                    <h5 class="modal-title" id="editModalLabel_<?= $rows['id'] ?>">Edit Basic Salary</h5>
                                                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label>Staff Name</label>
                                                        <input type="text" class="form-control" value="<?= htmlspecialchars($rows['name']) ?>" disabled>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Amount</label>
                                                        <input type="number" step="any" class="form-control" name="edit_amount" value="<?= $rows['amount'] ?>" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name="update_salary" class="btn btn-success">Save Changes</button>
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <?php
                
                                $counter++;
                            endwhile;
                
                            echo "</tbody></table>";
                        else:
                            echo "<h4>No salary records available.</h4>";
                        endif;
                        ?>
                    </div>
                