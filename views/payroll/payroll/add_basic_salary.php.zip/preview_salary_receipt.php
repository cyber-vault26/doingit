

<?php
 $staffDetails = selectSubsidiaryById($conn, (int) $_GET['staff_id']);
    if ($staffDetails && is_array($staffDetails)) {
        $basicSalary = (float) $_GET['bs'];
        $allowanceAmount = 0;
        $allowance = selectAllowanceByStaffId($conn, (int) $_GET['staff_id']);
        if ($allowance && is_array($allowance)) {
            $allowanceAmount = (float) $allowance['amount'];
        }
        $grossSalary = $basicSalary + $allowanceAmount;
        $nssf = $basicSalary * 0.10;
        $payee = calculatePayee($grossSalary);
        $netPay = $grossSalary - $nssf - $payee;
        ?>

        <div class="card card-info my-3 print-preview-unique-xyz">
            <div class="card-header">
                <h5 class="mb-0">Salary Receipt Preview</h5>
            </div>
            <div class="card-body">
                <style>
                    .cs-salary-slip * {
                        font-family: Arial, sans-serif;
                        color: #333;
                    }

                    .cs-salary-slip {
                        background: #ffffff;
                    }

                    .cs-company-header {
                        text-align: center;
                        padding: 20px;
                        margin-bottom: 25px;
                        border-bottom: 2px solid #007bff;
                    }

                    .cs-company-logo {
                        width: 80px;
                        height: 80px;
                        background-color: #f8f9fa;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 24px;
                        font-weight: bold;
                        margin: 0 auto 15px;
                        border: 2px solid #dee2e6;
                        color: #495057;
                    }

                    .cs-company-header h4 {
                        margin: 10px 0 5px 0;
                        font-size: 1.5rem;
                        font-weight: bold;
                        color: #333;
                    }

                    .cs-company-header h3 {
                        margin: 15px 0 0 0;
                        font-size: 1.75rem;
                        font-weight: bold;
                        color: #007bff;
                    }

                    .cs-company-header p {
                        margin: 5px 0;
                        color: #666;
                        font-size: 0.95rem;
                    }

                    .cs-info-section {
                        background: #f8f9fa;
                        border-radius: 5px;
                        padding: 20px;
                        margin-bottom: 20px;
                        border-left: 4px solid #007bff;
                    }

                    .cs-salary-section {
                        background: #ffffff;
                        border-radius: 5px;
                        padding: 20px;
                        margin-bottom: 20px;
                        border: 1px solid #dee2e6;
                    }

                    .cs-section-title {
                        font-size: 1.2rem;
                        font-weight: bold;
                        color: #333;
                        margin-bottom: 15px;
                        padding-bottom: 5px;
                        border-bottom: 1px solid #007bff;
                    }

                    .cs-slip-row {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        padding: 12px 0;
                        border-bottom: 1px solid #f0f0f0;
                    }

                    .cs-slip-row:last-child {
                        border-bottom: none;
                    }

                    .cs-slip-label {
                        font-weight: 600;
                        color: #333;
                        flex: 0 0 200px;
                        font-size: 1rem;
                    }

                    .cs-slip-value {
                        color: #333;
                        font-weight: 500;
                        flex: 1;
                        text-align: right;
                        font-size: 1rem;
                        background: #f8f9fa;
                        padding: 5px 10px;
                        border-radius: 3px;
                    }

                    .cs-section-divider {
                        height: 1px;
                        background: #dee2e6;
                        margin: 15px 0;
                    }

                    .cs-net-pay-highlight {
                        background-color: #e8f5e8;
                        margin: 15px -20px -20px;
                        padding: 20px;
                        border-top: 2px solid #28a745;
                    }

                    .cs-net-pay-highlight .cs-slip-label,
                    .cs-net-pay-highlight .cs-slip-value {
                        font-size: 1.2em;
                        font-weight: bold;
                        color: #155724;
                    }

                    .cs-month-display {
                        background-color: #e3f2fd;
                        padding: 15px;
                        border-radius: 5px;
                        margin-bottom: 20px;
                        border-left: 4px solid #2196f3;
                    }

                    .cs-month-display .cs-slip-row {
                        border-bottom: none;
                        padding: 5px 0;
                    }

                    .cs-month-display .cs-slip-label,
                    .cs-month-display .cs-slip-value {
                        color: #1565c0;
                        font-weight: bold;
                    }

                    /* Print Styles */
                    @media print {
                        body * {
                            visibility: hidden !important;
                        }

                        .print-preview-unique-xyz,
                        .print-preview-unique-xyz * {
                            visibility: visible !important;
                        }

                        .print-preview-unique-xyz {
                            position: absolute;
                            top: 0;
                            left: 0;
                            width: 100% !important;
                            max-width: none !important;
                            margin: 0 !important;
                            padding: 0 !important;
                            box-shadow: none !important;
                            border: none !important;
                        }

                        .print-preview-unique-xyz .card-header {
                            display: none !important;
                        }

                        .print-preview-unique-xyz .card-body {
                            padding: 20px !important;
                        }

                        .cs-company-header {
                            border-bottom: 2px solid #000 !important;
                        }

                        .cs-company-logo {
                            background-color: #f0f0f0 !important;
                            border: 1px solid #000 !important;
                            color: #000 !important;
                        }

                        .cs-section-divider {
                            background: #000 !important;
                        }

                        .cs-net-pay-highlight {
                            background-color: #f0f0f0 !important;
                            border-top: 2px solid #000 !important;
                        }

                        .cs-net-pay-highlight .cs-slip-label,
                        .cs-net-pay-highlight .cs-slip-value {
                            color: #000 !important;
                        }

                        .cs-month-display {
                            background-color: #f0f0f0 !important;
                            border-left: 2px solid #000 !important;
                        }

                        .no-print {
                            display: none !important;
                        }
                    }
                </style>

                <div class="cs-salary-slip">
                    <!-- Company Header -->
                    <div class="cs-company-header">
                        <?php if (file_exists('./resources/logo/logo_1_125x125.jpg')): ?>
                            <img src="./resources/logo/logo_1_125x125.jpg" alt="Logo" style="width: 80px; height: 80px; border-radius: 50%;">
                        <?php else: ?>
                            <div class="cs-company-logo">CS</div>
                        <?php endif; ?>
                        
                        <h4>BUILDSCAPE ENGINEERING</h4>
                        <p>Dar es Sallam|| MOBILE:+25567xxxxxxx || +2557xxxxxxx</p>
                        <p>ADDRESS: P.O. Box XXXX , DSM, Tanzania</p>
                        <h3>Salary Slip</h3>
                    </div>

                    <!-- Month Selection (hidden in print) -->
                    <div class="no-print mb-4">
                        <div class="row">
                            <div class="col-md-6 ms-auto">
                                <label for="monthInput" class="form-label">Select Month:</label>
                                <input type="month" id="monthInput" class="form-control" required onchange="updateMonthText()">
                            </div>
                        </div>
                    </div>

                    <!-- Month Display -->
                    <div class="cs-month-display">
                        <div class="cs-slip-row">
                            <div class="cs-slip-label">Month:</div>
                            <div class="cs-slip-value"><strong><span id="printedMonth">__________</span></strong></div>
                        </div>
                    </div>

                    <!-- Employee Information Section -->
                    <div class="cs-info-section">
                        <div class="cs-section-title">Employee Information</div>
                        <div class="cs-slip-row">
                            <div class="cs-slip-label">Name:</div>
                            <div class="cs-slip-value"><?= htmlspecialchars($staffDetails['name']) ?></div>
                        </div>

                        <div class="cs-slip-row">
                            <div class="cs-slip-label">Position/Title:</div>
                            <div class="cs-slip-value"><?= htmlspecialchars($staffDetails['subcategory']) ?></div>
                        </div>

                        <div class="cs-slip-row">
                            <div class="cs-slip-label">Phone:</div>
                            <div class="cs-slip-value"><?= htmlspecialchars($staffDetails['phone']) ?></div>
                        </div>
                    </div>

                    <!-- Salary Information Section -->
                    <div class="cs-salary-section">
                        <div class="cs-section-title">Salary Breakdown</div>
                        <div class="cs-slip-row">
                            <div class="cs-slip-label">Basic Salary:</div>
                            <div class="cs-slip-value">TSh <?= number_format($basicSalary, 2) ?></div>
                        </div>

                        <div class="cs-slip-row">
                            <div class="cs-slip-label">Allowance:</div>
                            <div class="cs-slip-value">TSh <?= number_format($allowanceAmount, 2) ?></div>
                        </div>

                        <div class="cs-slip-row">
                            <div class="cs-slip-label">Gross Salary:</div>
                            <div class="cs-slip-value">TSh <?= number_format($grossSalary, 2) ?></div>
                        </div>

                        <div class="cs-section-divider"></div>

                        <div class="cs-slip-row">
                            <div class="cs-slip-label">NSSF (10%):</div>
                            <div class="cs-slip-value">TSh <?= number_format($nssf, 2) ?></div>
                        </div>

                        <div class="cs-slip-row">
                            <div class="cs-slip-label">PAYE:</div>
                            <div class="cs-slip-value">TSh <?= number_format($payee, 2) ?></div>
                        </div>

                        <!-- Net Pay Highlight -->
                        <div class="cs-net-pay-highlight">
                            <div class="cs-slip-row">
                                <div class="cs-slip-label">Net Pay:</div>
                                <div class="cs-slip-value">TSh <?= number_format($netPay, 2) ?></div>
                            </div>
                        </div>
                    </div>

                    <!-- Print Button -->
                    <div class="text-center mt-3 no-print">
                        <button class="btn btn-primary btn-lg" onclick="window.print()">
                            <i class="fas fa-print me-2"></i>Print Salary Slip
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function updateMonthText() {
                const input = document.getElementById('monthInput');
                const output = document.getElementById('printedMonth');
                if (input.value) {
                    // Parse the input value directly as year-month
                    const [year, month] = input.value.split('-');
                    const monthNames = [
                        'January', 'February', 'March', 'April', 'May', 'June',
                        'July', 'August', 'September', 'October', 'November', 'December'
                    ];
                    const monthName = monthNames[parseInt(month) - 1];
                    output.textContent = `${monthName} ${year}`;
                } else {
                    output.textContent = '__________';
                }
            }

                        // Set current month as default
            window.addEventListener('DOMContentLoaded', function() {
                const monthInput = document.getElementById('monthInput');
                const currentDate = new Date();
                const currentMonth = currentDate.toISOString().slice(0, 7);
                monthInput.value = currentMonth;
                updateMonthText();
            });
        </script>

        <?php
    }